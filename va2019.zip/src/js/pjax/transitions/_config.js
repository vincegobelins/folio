/**
 *
 * Transition Configuration
 *
 * For each new Transition, please import
 * and add in transitionsClasses constant
 */

import Transition from './../transitions/transition';
import Poster from './../transitions/poster';

export const transitionClasses = {
    Transition,
    Poster
};