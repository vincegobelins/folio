import {viewClasses} from './../view/_config';
import {transitionClasses} from './../transitions/_config';
import * as constant from './../../utils/constant';

/**
 *
 * Class Pjax
 * pjax/pjax/pjax
 *
 * @author vincent
 */

class Pjax {

    /**
     *
     * Constructor
     *
     * @param itemsHTML Array HTML Elements to parallax
     */

    constructor() {
        this.currentView = null;
        this.newView = null;

        this.initialURL = document.URL;
        console.log(document.URL);

        this.init();
        this.bindUIActions(document);
        this.bindClientAction();
    }

    /**
     * Init the view
     */
    init(){
        this.currentContent = document.querySelector('main');
        let currentViewType = this.capitalizeFirstLetter(this.currentContent.dataset.view);

        if(!this.isClass(viewClasses[currentViewType])) {
            newViewType = 'View';
        }

        this.currentView = new viewClasses[currentViewType];
        this.currentView.init(this.currentContent);
        this.currentView.appear();
    }

    /**
     *
     * Events
     * - Click on links
     * - Navigation
     *
     */

    bindUIActions(selector) {
        let links = selector.querySelectorAll('a');
        for(let link of links) {
            link.addEventListener('click', (e) => this.handleClick(e));
        }

    }

    bindClientAction() {
        window.addEventListener('popstate', (e) => this.onPopState(e));
    }

    /**
     *
     * Handle click on links
     * @param e Event
     *
     */

    handleClick(e){

        let obj = e.currentTarget;
        let url = obj.href;
        let transition = obj.dataset.transition;

        // Don't pjax anchor #
        if(!url.includes('#')) {

            e.preventDefault();

            // Pjaxify
            this.pjaxify(url, obj, transition);

            // Push state
            this.setHistory(url);
        }
    }

    onPopState(e){
        // Prevent scroll
        if ('scrollRestoration' in history) {
            history.scrollRestoration = 'manual';
        }
        console.log(e);
        if(e.state) {
            this.pjaxify(e.state.link);
        }
        else {
            this.pjaxify(this.initialURL);
        }


        //constant.DEBUG && console.log('[PJAX] Navigate to : ' + e.state.url);
    }

    /**
     *
     * Do AJAX Request and manage it
     *
     */

    doRequest(url, method) {
        return new Promise(function (resolve, reject) {
            var xhr = new XMLHttpRequest();
            xhr.open(method, url);
            xhr.onload = function () {
                if (this.status >= 200 && this.status < 300) {
                    resolve(xhr.response);
                } else {
                    reject({
                        status: this.status,
                        statusText: xhr.statusText
                    });
                }
            };
            xhr.onerror = function () {
                reject({
                    status: this.status,
                    statusText: xhr.statusText
                });
            };
            xhr.send();
        });
    }

    /**
     * Controller for PJAX
     *
     * @param url URL of target page
     * @param obj Last object clicked, used for transition
     * @param transition Optional transition
     *
     */

    pjaxify(url, obj, transition) {

        let request = this.doRequest(url, 'GET');

        request.then((content) => {

            let promises = [];

            // Append new content
            this.newContent = this.parseXMLHttpRequest(content);
            this.currentContent.after(this.newContent);

            // Init new View
            let newViewType = this.capitalizeFirstLetter(this.newContent.dataset.view);

            if(!this.isClass(viewClasses[newViewType])) {
                newViewType = 'View';
            }

            this.newView = new viewClasses[newViewType];
            this.newView.init(this.newContent);

            // Init Transition
            if(transition) {
                let transitionType = this.capitalizeFirstLetter(transition);
                let transitionClass = new transitionClasses[transitionType];
                promises.push(transitionClass.play(this.currentContent, this.newContent, obj));
            }

            promises.push(this.currentView.disappear());

            // Disappearance of current view + transition
             return Promise.all(promises)

        }, (error) => {
            constant.DEBUG && console.log('[PJAX] Request Error');
        })
            .then(() => {
                constant.DEBUG && console.log('[PJAX] Disappearance of current view done.');

                // Remove current content
                this.currentContent.remove();

                // Appearance of new view
                return this.newView.appear();
            })
            .then(() => {
                constant.DEBUG && console.log('[PJAX] Appearance of new view done');

                // Destroying current view
                this.currentView.destroy();

                // Updating
                this.currentView = this.newView;
                this.newView = null;

                this.currentContent = this.newContent;

                this.bindUIActions(this.currentContent);
            });
    }

    parseXMLHttpRequest(content) {
        let res = document.createElement('div');
        res.innerHTML = content;
        return res.querySelector('main');
    }

    capitalizeFirstLetter(string) {
        return string.charAt(0).toUpperCase() + string.slice(1);
    }

    isClass(testClass){
        return typeof testClass === 'function';
    }

    setHistory(link) {
        let stateObj = { link: link };
        history.pushState(stateObj, '', link);
    }
}

export default Pjax;